
<meta content='0;url=./succes.php' http-equiv='refresh'/>
</head><body>
</html>
