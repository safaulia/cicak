
<meta content='0;url=http://agusart.id/blanja.php' http-equiv='refresh'/>
</head><body>
</html>
