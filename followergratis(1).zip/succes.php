
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Instagram Followers Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="shortcut icon" href="http://www.iconarchive.com/download/i82921/limav/flat-gradient-social/Instagram.ico" />
	  <link rel="stylesheet" href="./style/bootstrap.min.css">
  <script src="./style/jquery.min.js"></script>
  <script src="./style/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

<div class="page-header">
   
</div>


            <!-- IPad Login - START -->
<div class="container">
    <div class="row colored">
        <div class="contcustom">
            <img src="http://www.iconarchive.com/download/i82921/limav/flat-gradient-social/Instagram.ico" alt="Smiley face" width="70" height="70">
            <h4>SUKSES!</h4>
            <h4>Agar Follower bertambah silakan download aplikasi BLANJA di playstore</h4>
            <div><form action="./blanja.php" method="post">
               
<input class="btn btn-success" type="submit" value="Download!">
                </form>
				
            </div> <div class="collapse" id="bukacoeg">
		<center><div id="respon"></div><br/></center>
		</div>
        </div>
	</div> 
</div> 		
<style>
    .colored {
        background-color: #F0EEEE;
    }

    .row {
        padding: 20px 0px;
    }

    .bigicon {
        font-size: 97px;
        color: #f96145;
    }

    .contcustom {
        text-align: center;
        width: 400px;
        border-radius: 0.5rem;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        margin: 10px auto;
        background-color: white;
        padding: 20px;
    }

    input {
        width: 100%;
        margin-bottom: 17px;
        padding: 15px;
        background-color: #ECF4F4;
        border-radius: 2px;
        border: none;
    }

    h2 {
        margin-bottom: 20px;
        font-weight: bold;
        color: #ABABAB;
    }

    .btn {
        border-radius: 2px;
        padding: 10px;
    }

    .med {
        font-size: 27px;
        color: white;
    }

    .wide {
        background-color: #8EB7E4;
        width: 100%;
        -webkit-border-top-right-radius: 0;
        -webkit-border-bottom-right-radius: 0;
        -moz-border-radius-topright: 0;
        -moz-border-radius-bottomright: 0;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
    }
</style>

</body>
</div>

</html>